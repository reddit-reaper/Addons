from resources.lib.externals.hachoir.hachoir_parser.misc.file_3do import File3do
from resources.lib.externals.hachoir.hachoir_parser.misc.file_3ds import File3ds
from resources.lib.externals.hachoir.hachoir_parser.misc.torrent import TorrentFile
from resources.lib.externals.hachoir.hachoir_parser.misc.ttf import TrueTypeFontFile
from resources.lib.externals.hachoir.hachoir_parser.misc.chm import ChmFile
from resources.lib.externals.hachoir.hachoir_parser.misc.lnk import LnkFile
from resources.lib.externals.hachoir.hachoir_parser.misc.pcf import PcfFile
from resources.lib.externals.hachoir.hachoir_parser.misc.ole2 import OLE2_File
from resources.lib.externals.hachoir.hachoir_parser.misc.pdf import PDFDocument
from resources.lib.externals.hachoir.hachoir_parser.misc.pifv import PIFVFile
from resources.lib.externals.hachoir.hachoir_parser.misc.hlp import HlpFile
from resources.lib.externals.hachoir.hachoir_parser.misc.gnome_keyring import GnomeKeyring
from resources.lib.externals.hachoir.hachoir_parser.misc.bplist import BPList

